from django.shortcuts import render, get_object_or_404
from .models import Product, Category

def index(request):
    return render(request, 'food/index.html')

def about(request):
    return render(request, 'food/about.html')

def contact(request):
    return render(request, 'food/contact.html')

# 🔥 ВОТ ЭТО МЕНЯЕМ
def shop(request):
    products = Product.objects.all()
    categories = Category.objects.all()

    q = request.GET.get('q')
    category_id = request.GET.get('category')

    if q:
        products = products.filter(name__icontains=q)

    if category_id:
        products = products.filter(category_id=category_id)

    return render(request, 'food/shop.html', {
        'products': products,
        'categories': categories
    })


